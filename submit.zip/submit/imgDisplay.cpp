//
// Created by Yuyang Tian on 2025/1/14.
// For Reading an image from a file and displaying it
//

#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>

using namespace cv;
using namespace std;

int main() {
    string image_path = "../outputs/progress.png";
    Mat img = imread(image_path);

    if (img.empty()) {
        cerr << "Could not read the image: " << image_path << endl;
        return 1;
    }

    imshow("My 2023 progress", img);
    cout << "Image loaded successfully.\n";

    int key = waitKey(0);

    if (key == 'q') { // pressing 'q', exit the program
        return 1;
    } else if (key == 's') { // pressing 's', save the outputs to outputs subfolder
        imwrite("../outputs/progress-2.png", img);
        cout << "Save the image: " << image_path << endl;
    }

    return 0;
}