Readme

Name: Yuyang Tian

operating system: Mac OS 1.13.1

IDE: CLion + Cmake

Extension video link: [Video showcase](https://drive.google.com/file/d/1_aYZx_wTCwwtKma4UQ_nRCyc7jp9FglT/view?usp=drive_link)

### File Overview:

1. **`imgDisplay.cpp`**:
   - Handles still image operations such as opening, displaying, and writing images to files.
   - Serves as the foundation for understanding basic image manipulation mechanics.
2. **`vidDisplay.cpp`**:
   - The core file for the live-stream video application.
   - Enables users to apply real-time filters to video streams using keyboard inputs.
   - Supported filters include grayscale, sepia, blur, Sobel X/Y, gradient magnitude, and face detection.
   - Relies on filter implementations from `filter.cpp`.
3. **`filterDisplay.cpp`**:
   1. Enables users to apply real-time filters to image using keyboard inputs.
   2. Supported filters include grayscale, sepia, blur.
4. **`filter.cpp`**:
   - Contains the implementations of various image filters used in the project.
   - Works as a reusable module for both still image processing and live video filtering.
5. **`da-video.cpp`**:
   - Focuses on generating a 3D Point Cloud from a depth map.
   - A specialized application for visualizing depth data in 3D.
6. **`pcl3d.h` and `pcl3d.cpp`**:
   - Introduced to support Task 11 (3D Point Cloud generation).
   - `pcl3d.h`: Header file defining the structures and functions for point cloud operations.
   - `pcl3d.cpp`: Implements the logic for generating and visualizing 3D point clouds from depth data.
7. **Meme Generator (`memeGenerator.cpp`)**:
   - An extension feature designed for creating memes.
   - Adds customizable top and bottom text to images with outlined styling for improved readability.
   - Allows real-time editing and live previews using OpenCV.